
public class ContinuingIntegerAction implements Action {

	@Override
	public InterimResult execute(InterimResult x, char c) {
		
		double number = c - '0';
		x.setV((x.getV()*10) + number);
		return x;
	}

}
