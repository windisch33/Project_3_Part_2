
public class PlusInputVerifier implements InputVerifier {

	@Override
	public boolean meetsCriteria(char c) {
		
		if(c == '=')
		{
			return true;
		}
		return false;
	}

}
