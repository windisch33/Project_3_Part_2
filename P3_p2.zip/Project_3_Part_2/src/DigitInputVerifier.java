
public class DigitInputVerifier implements InputVerifier {

	@Override
	public boolean meetsCriteria(char c) {
		 
		if(c >= '0' && c <= '9')
		{
			return true;
		}
		return false;
	}

}
