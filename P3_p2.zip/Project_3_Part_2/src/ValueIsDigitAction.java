
public class ValueIsDigitAction implements Action {

	@Override
	public InterimResult execute(InterimResult x, char c) {
		
		double number = c - '0';
		x.setV(number);
		return x;
	}

}
