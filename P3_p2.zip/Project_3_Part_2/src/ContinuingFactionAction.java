
public class ContinuingFactionAction implements Action {

	@Override
	public InterimResult execute(InterimResult x, char c) {
		
		double number = c - '0';
		x.setV(x.getV()+(x.getP()*number));
		x.setP(.1/10);
		return x;
	}

}
