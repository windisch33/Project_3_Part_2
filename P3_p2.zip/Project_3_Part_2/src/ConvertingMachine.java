/**
 * A finite state machine that parses a string containing a real number. Will
 * throw NumberFormatExcaption if the string doesn't not contain a legal
 * representation of a real number. Note: we are not dealing with scientific
 * notation
 * 
 * @author Merlin
 *
 */
public class ConvertingMachine
{
	Edge currentEdge;
	State currentState;
	InputVerifier inputVerifier;
	Action action;
	State nextState;
	InterimResult currentResult;
	
	
	private final Edge[] machine =
	{
			new Edge(State.START, new DigitInputVerifier(),new ValueIsDigitAction(), State.INTEGER),
			new Edge(State.START, new MinusInputVerifier(), new NegateAction(),State.INTEGER),
			new Edge(State.START, new PlusInputVerifier(), new NoAction(),State.INTEGER),
			new Edge(State.START, new PeriodInputVerifier(),new StartFraction(), State.DECIMAL),
			new Edge(State.INTEGER, new DigitInputVerifier(),new ContinuingIntegerAction(), State.INTEGER),
			new Edge(State.INTEGER, new PeriodInputVerifier(),new StartFraction(), State.DECIMAL),
			new Edge(State.DECIMAL, new DigitInputVerifier(),new ContinuingFactionAction(), State.DECIMAL)

	};

	public ConvertingMachine()
	{
		currentState = State.START;
		currentResult = new InterimResult(0,1,0);
		
	}
	public double parse(String text)throws NumberFormatException
	{
		try {
			Double.parseDouble(text);
		} catch (NumberFormatException NFE) {
		  throw NFE;
		}
		double result;
		int i = 0;
		while(i < text.length())
		{
			currentEdge = searchForEdge(currentState, text.charAt(i));
			currentResult = currentEdge.action.execute(currentResult, text.charAt(i));
			currentState = currentEdge.nextState;
			i++;
		}
		result = currentResult.getV() * currentResult.getS(); 
		return result;
		
	}

	private Edge searchForEdge(State currentState, char ch)
	{
		int i;
		for(i = 0;i < 7;i++)
		{
			if (machine[i].currentState == currentState)
			{
				inputVerifier =  machine[i].inputVerifier;
				if(inputVerifier.meetsCriteria(ch))
				{
					return machine[i];
				}
					
			}
		}
		return null;
		
	}

	private class Edge
	{
		State currentState;
		InputVerifier inputVerifier;
		Action action;
		State nextState;

		public Edge(State currentState, InputVerifier inputVerifier,
				Action action, State nextState)
		{
			this.currentState = currentState;
			this.inputVerifier = inputVerifier;
			this.action = action;
			this.nextState = nextState;
		}
	}

	private enum State
	{
		START, INTEGER, DECIMAL, END
	}
}
